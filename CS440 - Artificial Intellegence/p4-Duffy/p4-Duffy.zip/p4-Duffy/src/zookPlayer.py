import sys
# print to stderr for debugging purposes
# remove all debugging statements before submitting your code
msg = "Given board " + sys.argv[1] + "\n";
sys.stderr.write(msg);

#parse the input string, i.e., argv[1]
 
#perform intelligent search to determine the next move

#print to stdout for AtroposGame
sys.stdout.write("(3,2,2,2)");
# As you can see Zook's algorithm is not very intelligent. He 
# will be disqualified.

