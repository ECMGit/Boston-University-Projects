Readme File for CS440 P0

- I completed my project in the CS undergrad laboratory (on Jellybean, which runs Windows 7).

- This program uses 2 separate windows to display the input and output feeds simultaneously. However, when the program starts, the windows overlap. Both windows are there even if you don't see it at first!