


int bitNor(int, int);
int test_bitNor(int, int);
int bitXor(int, int);
int test_bitXor(int, int);
int isNotEqual(int, int);
int test_isNotEqual(int, int);
int getByte(int, int);
int test_getByte(int, int);
int copyLSB(int);
int test_copyLSB(int);
int logicalShift(int, int);
int test_logicalShift(int, int);
int bitCount(int);
int test_bitCount(int);
int bang(int);
int test_bang(int);
int leastBitPos(int);
int test_leastBitPos(int);
int tmax();
int test_tmax();
int isNonNegative(int);
int test_isNonNegative(int);
int isGreater(int, int);
int test_isGreater(int, int);
int divpwr2(int, int);
int test_divpwr2(int, int);
int abs(int);
int test_abs(int);
int addOK(int, int);
int test_addOK(int, int);
